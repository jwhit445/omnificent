export class UserStats {
    Id: string;
    EntityType: string;
    Username: string;
    Wins: number;
    Losses: number;
    RoCoMMR: number;
    RankPosition: number;
}